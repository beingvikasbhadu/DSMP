package com.example.MarkdownApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MarkdownAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(MarkdownAppApplication.class, args);
	}

}
